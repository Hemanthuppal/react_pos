import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';

import ItemForm from "./Components/Pages/Admin/Items/Items";
import MenuItems from "./Components/Pages/Admin/Items/ItemsDisplay";







function App() {
    return (
        <Router>
            <div>
            
                <Routes>
                    <Route path="/items" exact element={<ItemForm/>} />
                    <Route path="/itemdisplay" exact element={<MenuItems/>}/>
                   
                    
                    
                </Routes>
        
            </div>
        </Router>
    );
}

export default App;
