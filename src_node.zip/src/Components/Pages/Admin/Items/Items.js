import React, { useState } from 'react';
import axios from 'axios';

const ItemForm = () => {
    const [formData, setFormData] = useState({
        item_name: '',
        item_code: '',
        category: '',
        description: '',
        price: '',
        portion_size: '',
        availability_status: true
    });
    const [image, setImage] = useState(null);

    const handleChange = e => {
        const { name, value, type, checked } = e.target;
        setFormData({
            ...formData,
            [name]: type === 'checkbox' ? checked : value
        });
    };

    const handleImageChange = e => {
        setImage(e.target.files[0]);
    };

    const handleSubmit = async e => {
        e.preventDefault();
        const formDataWithImage = new FormData();
        for (const key in formData) {
            formDataWithImage.append(key, formData[key]);
        }
        if (image) formDataWithImage.append('image', image);

        try {
            const res = await axios.post('http://localhost:5000/add-item', formDataWithImage, {
                headers: { 'Content-Type': 'multipart/form-data' }
            });
            alert(res.data.message);
        } catch (err) {
            console.error(err);
            alert('Error adding item');
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <label>Item Name:</label>
            <input type="text" name="item_name" value={formData.item_name} onChange={handleChange} />

            <label>Item Code/ID:</label>
            <input type="text" name="item_code" value={formData.item_code} onChange={handleChange} />

            <label>Category:</label>
            <select name="category" value={formData.category} onChange={handleChange}>
                <option value="">Select Category</option>
                <option value="Appetizers">Appetizers</option>
                <option value="Mains">Mains</option>
                <option value="Desserts">Desserts</option>
                <option value="Beverages">Beverages</option>
            </select>

            <label>Description:</label>
            <textarea name="description" value={formData.description} onChange={handleChange} />

            <label>Price:</label>
            <input type="number" name="price" value={formData.price} onChange={handleChange} />

            <label>Portion Size:</label>
            <select name="portion_size" value={formData.portion_size} onChange={handleChange}>
                <option value="">Select Portion Size</option>
                <option value="Small">Small</option>
                <option value="Medium">Medium</option>
                <option value="Large">Large</option>
            </select>

            <label>Image:</label>
            <input type="file" onChange={handleImageChange} />

            <label>Availability Status:</label>
            <input type="checkbox" name="availability_status" checked={formData.availability_status} onChange={handleChange} />

            <button type="submit">Add Item</button>
        </form>
    );
};

export default ItemForm;
