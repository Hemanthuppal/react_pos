import React, { useEffect, useState } from 'react';
import axios from 'axios';

const MenuItems = () => {
  const [menuItems, setMenuItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchMenuItems = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/menu-items');
        console.log(response.data); // Log the response to check its structure
        setMenuItems(response.data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchMenuItems();
  }, []);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error}</p>;

  return (
    <div>
      <h1>Menu Items</h1>
      <table>
        <thead>
          <tr>
            <th>Item Name</th>
            <th>Item Code</th>
            <th>Category</th>
            <th>Description</th>
            <th>Price</th>
            <th>Portion Size</th>
            <th>Status</th>
            <th>Image</th>
          </tr>
        </thead>
        <tbody>
          {menuItems.map(item => (
            <tr key={item.id}> {/* Adjust key based on your item ID */}
              <td>{item.item_name}</td> {/* Make sure this matches your DB column names */}
              <td>{item.item_code}</td>
              <td>{item.category}</td>
              <td>{item.description}</td>
              <td>${item.price}</td>
              <td>{item.portion_size}</td>
              <td>{item.availability_status ? 'Available' : 'Unavailable'}</td>
              <td>
                {item.image_url && (
                  <img src={`http://localhost:5000${item.image_url}`} alt={item.item_name} style={{ width: '50px', height: '50px' }} />
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default MenuItems;
